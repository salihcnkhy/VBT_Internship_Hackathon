import 'package:flutter/material.dart';
import './learn_page_view_model.dart';
  
class LearnPageView extends LearnPageViewModel {
    
  @override
  Widget build(BuildContext context) {
    
    // Replace this with your build function
    return Text('Just a placeholder');
  }
}

