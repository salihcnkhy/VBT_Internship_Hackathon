import 'package:flutter/material.dart';
import './learn_page.dart';

abstract class LearnPageViewModel extends State<LearnPage> {
  // Add your state and logic here
}
