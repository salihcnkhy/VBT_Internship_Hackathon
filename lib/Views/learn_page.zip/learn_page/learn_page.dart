import 'package:flutter/material.dart';
import './learn_page_view.dart';

class LearnPage extends StatefulWidget {
  
  @override
  LearnPageView createState() => new LearnPageView();
}
  
